A=(22,22)
print("Sum Of Tuple Elements---> ",sum(A))
