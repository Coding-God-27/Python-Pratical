A=(1,22,3,4)
print("Maximum Element of Tuple is---> ",max(A))
print("Minimum Element of Tuple is---> ",min(A))
