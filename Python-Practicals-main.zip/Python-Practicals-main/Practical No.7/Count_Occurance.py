print("Counting Occurances of Tuple")
A=((),(),(),())
print(len(A))
