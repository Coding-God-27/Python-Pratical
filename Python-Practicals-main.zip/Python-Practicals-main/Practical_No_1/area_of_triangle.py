# Program to calculate the area of triangle
H,B = map(int,input("Enter Height and breadth of Triangle---> ").split())
print("AREA OF TRIANLGE---> ",0.5*H*B,"sq. units")
