# Program to add two numbers
A,B = map(int,input("Enter 2 Numbers---> ").split()) # Taking values from user.
print("Addition of two numbers---> ",A+B)
