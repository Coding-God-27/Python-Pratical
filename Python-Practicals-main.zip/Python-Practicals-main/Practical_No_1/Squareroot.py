#Program To find SquareRoot of given Number.

N = int(input("ENTER THE NUMBER---> "))
S = N ** 0.5
print("Squareroot of {0} is {1}".format(N,int(S)))
