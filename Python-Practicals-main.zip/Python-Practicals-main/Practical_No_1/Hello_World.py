#HelloWorld Program
print("Hello World")
