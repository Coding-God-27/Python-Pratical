#Program to swap two variables
A = input("Enter value for variable---> ")
B = input("Enter value for variable---> ")
print("A = {0} and B = {1}\n".format(A,B))
print("Values Are Swapped!")
A,B = B,A
print("A = {0} and B = {1}".format(A,B))
