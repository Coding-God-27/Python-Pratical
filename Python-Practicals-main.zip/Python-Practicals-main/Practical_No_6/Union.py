L1=list(map(int,input().split()))
L2=list(map(int,input().split()))
print(set().union(L1,L2))
