A=list(input().split(" "))
word=input()
print(A.count(word))
