A = input("Enter String: ")
word_list = A.split()
N = len(word_list)
print(N)
