print("Sort Python Dictionary")
A={1:11,2:0,0:0}
print(sorted(A.items()))
