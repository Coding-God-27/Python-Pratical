c=dict(zip(input("Enter Keys---> ").split(),input("Enter Values---> ").split()))
print(c)
