#Print elements of array present in on even position
A=[10,20,30,40,50,60,70,80,90,100]
for i in range(1,len(A),2):
    print(A[i],end=" ")
