#Sort elements in ascending and descending order
A=[10,20,11,1,5,2,-5,0]
print("Orginal List---> ",A)
print()
print("Sorting List in Ascending Order.")
A=sorted(A)
print("List In ascending order---> ",A)
print("List In descending order---> ",A[::-1])

