#Python Program to print elements of array in reverse order
A=list(map(int,input("Enter Elements--> ").split()))
print()
print("List Elements Are---> ",A)
print()
print("List in reverse order")
print(A[::-1])
