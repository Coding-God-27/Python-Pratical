#Copy all elements of one array into another.
A=[1,2,3,4,5]
print("A---> ",A)
B=[]
for i in A:
    B.append(i)
print("B---> ",B)
