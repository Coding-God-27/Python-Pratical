# Convert Binary to Decimal
B=input("Enter Binary Number---> ")
print(B,"in decimal number is",int(B,2))
