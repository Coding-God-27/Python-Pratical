# Convert Decimal to Binary
D=int(input("ENTER A NUMBER--> "))
print(D,"in binary is",bin(D))
